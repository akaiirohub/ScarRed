/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public abstract class Adicionando extends Decorator {
    protected Decorator decorador;

	public Adicionando(String descricao, Decorator deco) {
		super(descricao);
		this.decorador = deco;
	}

	public abstract String getDescricao();
}
