/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu0
 * 
 */
public class Gelo extends Adicionando{
    public Gelo(Decorator deco) {
		super("Gelo", deco);
	}

	@Override
	public String getDescricao() {
		return decorador.getDescricao() + " com Gelo ";
	}

	@Override
	public double custo() {
		return decorador.custo() + 1;
	}
}
