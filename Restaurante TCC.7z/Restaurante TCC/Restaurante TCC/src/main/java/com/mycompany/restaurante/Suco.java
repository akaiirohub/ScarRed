/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public class Suco extends Decorator{
    public Suco() {
		super("Suco ");
	}

	@Override
	public double custo() {
		return 0;       //OBS:Coloquei intencionalmente valor 0 
	}
}

