/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public class Pedido implements Command {
    private Chefe chefe;
    private int comida;
	public Pedido(Chefe chefe, int comida) {
		this.chefe = chefe;
		this.comida = comida;
	}
	@Override
	public void executa() {
		if (this.comida == 1) {
			this.chefe.CozinharPratoPrincipal();
		} 
                else if(this.comida == 2){
			this.chefe.CozinharPorcaoGrande();
		}
                else if(this.comida == 3){
			this.chefe.CozinharBolo();
		}
                else if(this.comida == 4){
			this.chefe.FazerBebida();
		}
                else if(this.comida == 0){
			this.chefe.Obrigado();
		}
                else{
                    this.chefe.PedidoErrado();
                }}}


