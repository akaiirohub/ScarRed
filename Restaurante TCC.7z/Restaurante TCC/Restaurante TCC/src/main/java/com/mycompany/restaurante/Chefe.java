/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

import java.util.Scanner;

/**
 *
 * @author Issamu
 */
public class Chefe {
    public void CozinharPratoPrincipal() {
		System.out.println("O cliente pediu prato Principal, e o Chefe está cozinhando com esforço no prato!!");
	}

	public void CozinharBolo() {
		System.out.println("O cliente pediu Sobremesa, e o Chefe está fazendo um belo sobremesa");
	}
        
        public void Obrigado() {
		System.out.println("Obrigado. Volte Sempre!");
	}
        
        public void CozinharPorcaoGrande(){
            System.out.println("O cliente fez pedido Secundário, e o Chefe está fazendo porções de comidas");
        }
        
        public void PedidoErrado() {
		System.out.println("O cliente fez o pedido que não estava no cardápio. O Garço está confuso!");
	}
       
        public void FazerBebida(){
            String resultadoBebidaComCachaca;
            String adicionandoSomenteGelo;
            String resultadoBebidaComTudo;            
            Suco suco = new Suco();
            Gelo adicionandoGelo = new Gelo(suco);
            adicionandoSomenteGelo = adicionandoGelo.getDescricao() + adicionandoGelo.custo();
            Cachaca adicionandoCachaca = new Cachaca(adicionandoGelo);
            resultadoBebidaComTudo =adicionandoCachaca.getDescricao() + adicionandoCachaca.custo();
            
            Cachaca adicionandoApenasCachaca = new Cachaca(suco);
            resultadoBebidaComCachaca = adicionandoApenasCachaca.getDescricao() + adicionandoApenasCachaca.custo();
            
            String RecebePedidoGelo;
            String RecebePedidoCachaca;
            String RespostaNormal = "SIM";
            String RespostaAbreviado = "S";
            Scanner ler = new Scanner(System.in);
            
            System.out.println("Deseja incluir Gelo no Suco? (Sim ou Nao)");
            RecebePedidoGelo = ler.next();
            System.out.println("Deseja incluir Cachaça no Suco? (Sim ou Nao)");
            RecebePedidoCachaca = ler.next();
            if(RespostaNormal.equals(RecebePedidoGelo.toUpperCase()) && RespostaNormal.equals(RecebePedidoCachaca.toUpperCase()) || 
               RespostaAbreviado.equals(RecebePedidoGelo.toUpperCase()) && RespostaAbreviado.equals(RecebePedidoCachaca.toUpperCase()) ||
               RespostaAbreviado.equals(RecebePedidoGelo.toUpperCase()) && RespostaNormal.equals(RecebePedidoCachaca.toUpperCase()) || 
               RespostaNormal.equals(RecebePedidoGelo.toUpperCase()) && RespostaAbreviado.equals(RecebePedidoCachaca.toUpperCase()))
            {    
            System.out.println("O Cliente pediu Bebida com Gelo e Cachaça\n");
            System.out.println("O valor da bebida "+(resultadoBebidaComTudo)+" reais mais cara: ");
            }
            else if(RespostaNormal.equals(RecebePedidoGelo.toUpperCase()) || RespostaAbreviado.equals(RecebePedidoGelo.toUpperCase()))
            {
            System.out.println("O Cliente pediu Bebida com Gelo");
            System.out.println("O valor da bebida "+(adicionandoSomenteGelo)+" real mais caro: ");
            }
            else if(RespostaNormal.equals(RecebePedidoCachaca.toUpperCase()) || RespostaAbreviado.equals(RecebePedidoCachaca.toUpperCase()))
            {
            System.out.println("O Cliente pediu Bebida com Cachaça");
            System.out.println("O valor da bebida "+(resultadoBebidaComCachaca)+" reais mais cara: ");
            }
            else{
            System.out.println("O pedido adicional foi Negado.");    
            }
        }
        
}


