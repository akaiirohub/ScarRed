/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public class DescricaoPratoBuilder implements Builder{
    private TipoPrato tipo;
    private int calorias;
    private Preco preco;
    private Tamanho tamanho;


    @Override
    public void setTipoPrato(TipoPrato tipo) {
        this.tipo = tipo;
    }
    @Override
    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }
    @Override
    public void setPreco(Preco preco) {
        this.preco = preco;
    }
    @Override
    public void setTamanho(Tamanho tamanho) {
        this.tamanho = tamanho;
    }
    public Descricao getResult() {
        return new Descricao(tipo, calorias, preco, tamanho);
    }
    
}

