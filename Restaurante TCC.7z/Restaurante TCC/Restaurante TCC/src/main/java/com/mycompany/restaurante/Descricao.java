/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public class Descricao {
    private final TipoPrato tipoPrato; //final utiliza para não ocorrer alterações
    private final int calorias;
    private final Preco preco;
    private final Tamanho tamanho;

    public Descricao(TipoPrato tipoPrato, int calorias, Preco preco, Tamanho tamanho) {
        this.tipoPrato = tipoPrato;
        this.calorias = calorias;
        this.preco = preco;
        this.tamanho = tamanho;

    }

    public String print() {
        String info = "";
        info += "Tipo de Prato: " + tipoPrato + "\n";
        info += "Quantidade de Calorias: " + calorias + "\n";
        info += "Preço:" + preco.getValor() +"\n";
        info += "Tamanho: " + tamanho + "\n";

        return info;
    }
}

