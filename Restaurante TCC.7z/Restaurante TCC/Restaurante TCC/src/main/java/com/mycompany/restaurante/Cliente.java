/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

import java.util.Scanner;

/**
 *
 * @author Issamu
 */
public class Cliente {
    public static void main(String[] args) throws InterruptedException {
                Scanner ler = new Scanner(System.in);
                
        Responsavel responsavel = new Responsavel();
        int finalizar = 1;
        int PedidoPrincipal = 1;
        int PedidoSecundario = 2;
        int PedidoSobremesa = 3;
        int PedidoBebida = 4;
        PratoBuilder construtor = new PratoBuilder();
        responsavel.construtorPrincipal(construtor);
        Prato prato = construtor.getResult();
        
    while (finalizar > 0) 
    {   
        System.out.println("Olá Cliente. Digite se deseja saber os detalhe de algum desses 3 tipos de Pratos? ");
                System.out.println("Digite 1 para PRINCIPAL ,2 para SECUNDARIO ,3 para SOBREMESA e 4 para BEBIDA :");
        System.out.println("Se caso não digite o número 0\n") ;  
        int RecebePedido = ler.nextInt();
        if(RecebePedido == PedidoPrincipal){
        responsavel.construtorPrincipal(construtor);
        prato = construtor.getResult();
        System.out.println("\n\nTipo do Prato:" + prato.recebeTipoPrato());    
        DescricaoPratoBuilder descricaoBuilder = new DescricaoPratoBuilder();
        responsavel.construtorPrincipal(descricaoBuilder);
        Descricao descricaoPrato = descricaoBuilder.getResult();
        System.out.println("\nDetalhes do Tipo de Prato Escolhido:\n" + descricaoPrato.print()); 
        Thread.sleep(4000);}
        else if(RecebePedido == PedidoSecundario){
        responsavel.construtorSecundario(construtor);
        prato = construtor.getResult();    
        System.out.println("\n\nTipo do Prato:" + prato.recebeTipoPrato());     
        DescricaoPratoBuilder descricaoBuilder = new DescricaoPratoBuilder();
        responsavel.construtorSecundario(descricaoBuilder);
        Descricao descricaoPrato = descricaoBuilder.getResult();
        System.out.println("\nDetalhes do Tipo de Prato Escolhido:\n" + descricaoPrato.print());  
        Thread.sleep(4000);}
        else if(RecebePedido == PedidoSobremesa){
        responsavel.construtorSobremesa(construtor);
        prato = construtor.getResult();    
        System.out.println("\n\nTipo do Prato:" + prato.recebeTipoPrato());    
        DescricaoPratoBuilder descricaoBuilder = new DescricaoPratoBuilder();
        responsavel.construtorSobremesa(descricaoBuilder);
        Descricao descricaoPrato = descricaoBuilder.getResult();
        System.out.println("\nDetalhes do Tipo de Prato Escolhido:\n" + descricaoPrato.print());  
        Thread.sleep(4000);}
        else if(RecebePedido == PedidoBebida){
        responsavel.construtorBebida(construtor);
        prato = construtor.getResult();    
        System.out.println("\n\nTipo do Prato:" + prato.recebeTipoPrato());    
        DescricaoPratoBuilder descricaoBuilder = new DescricaoPratoBuilder();
        responsavel.construtorBebida(descricaoBuilder);
        Descricao descricaoPrato = descricaoBuilder.getResult();
        System.out.println("\nDetalhes do Tipo de Bebida Escolhido:\n" + descricaoPrato.print());  
        Thread.sleep(4000);}
        else if(RecebePedido == 0){
            finalizar = RecebePedido;}
        else{
        System.out.println("\n\nNão existe o tipo que foi digitado:\n");  }
    }
    finalizar = 1;
    
    
		Chefe chefe = new Chefe();
        
                while (finalizar > 0) 
                {
                System.out.printf("\n\n Informe o pedido que deseja. Digite 1 para Principal,\n"
                        + " 2 para Secundario, 3 para Sobremesa ou 4 para Bebida.\n");
                System.out.printf("Caso não deseja fazer pedido digite 0.\n\n");
                int PedidoCliente = ler.nextInt();      
                
                if(PedidoCliente == 0)
                {
                finalizar = PedidoCliente;
                }
                Pedido pedido = new Pedido(chefe, PedidoCliente);
		Garcom garcom = new Garcom(pedido);
		garcom.executa();      
                Thread.sleep(3000);
                }        
	}
}

