/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public class Responsavel {
    public void construtorPrincipal(Builder builder) {
        builder.setTipoPrato(TipoPrato.PRINCIPAL);
        builder.setCalorias(950);
        builder.setPreco(new Preco(34.50));
        builder.setTamanho(Tamanho.MEDIO);
    }

    public void construtorSecundario(Builder builder) {
        builder.setTipoPrato(TipoPrato.SECUNDARIO);
        builder.setCalorias(1123);
        builder.setPreco(new Preco(25.30));
        builder.setTamanho(Tamanho.GRANDE);
    }
    public void construtorSobremesa(Builder builder) {
        builder.setTipoPrato(TipoPrato.SOBREMESA);
        builder.setCalorias(700);
        builder.setPreco(new Preco(20.85));
        builder.setTamanho(Tamanho.PEQUENO);
    }
    public void construtorBebida(Builder builder) {
        builder.setTipoPrato(TipoPrato.BEBIDA);
        builder.setCalorias(300);
        builder.setPreco(new Preco(8.50));
        builder.setTamanho(Tamanho.MEDIO);
    }
}
