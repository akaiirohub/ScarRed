/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public class Cachaca extends Adicionando {
    public Cachaca(Decorator deco) {
		super("Cachaça", deco);
	}

	@Override
	public String getDescricao() {
		return decorador.getDescricao() + " e com Cachaça Ficou ";
	}

	@Override
	public double custo() {
		return decorador.custo() + 7;
	}
}
