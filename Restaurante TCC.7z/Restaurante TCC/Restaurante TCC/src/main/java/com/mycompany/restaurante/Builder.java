/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.restaurante;

/**
 *
 * @author Issamu
 */
public interface Builder {
    void setTipoPrato(TipoPrato tipo);//tipo de prato (sobremesa, principal)
    void setCalorias(int calorias);//caloria1
    void setPreco(Preco preco);//preço
    void setTamanho(Tamanho tamanho);//tamanho (pequeno,medio,grande)
}

